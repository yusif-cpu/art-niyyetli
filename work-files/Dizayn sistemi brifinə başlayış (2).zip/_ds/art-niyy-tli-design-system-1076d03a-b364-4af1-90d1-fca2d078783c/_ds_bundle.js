/* @ds-bundle: {"format":4,"namespace":"ArtNiyyTliDesignSystem_1076d0","components":[{"name":"ArtistCard","sourcePath":"components/catalog/ArtistCard.jsx"},{"name":"ArtworkCard","sourcePath":"components/catalog/ArtworkCard.jsx"},{"name":"ArtworkMeta","sourcePath":"components/catalog/ArtworkMeta.jsx"},{"name":"ExhibitionRow","sourcePath":"components/catalog/ExhibitionRow.jsx"},{"name":"SpecTable","sourcePath":"components/catalog/SpecTable.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"SectionHeader","sourcePath":"components/core/SectionHeader.jsx"},{"name":"TextLink","sourcePath":"components/core/TextLink.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"FilterChip","sourcePath":"components/forms/FilterChip.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Breadcrumb","sourcePath":"components/navigation/Breadcrumb.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination.jsx"},{"name":"SiteFooter","sourcePath":"components/navigation/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"components/navigation/SiteHeader.jsx"}],"sourceHashes":{"components/catalog/ArtistCard.jsx":"bd9c8594c782","components/catalog/ArtworkCard.jsx":"1bc91cb2e8b1","components/catalog/ArtworkMeta.jsx":"78fdaf9c8764","components/catalog/ExhibitionRow.jsx":"41eeace009b0","components/catalog/SpecTable.jsx":"fb4b014a0bce","components/core/Badge.jsx":"b26351069b72","components/core/Button.jsx":"204b8b7b4cc2","components/core/Divider.jsx":"a72e0a192f93","components/core/SectionHeader.jsx":"5603629732ed","components/core/TextLink.jsx":"87c31f995005","components/forms/Checkbox.jsx":"c053823190f3","components/forms/FilterChip.jsx":"7e847057fb33","components/forms/Input.jsx":"e9f13fb9303d","components/forms/Select.jsx":"6b1a573658d1","components/forms/Textarea.jsx":"d6b232acef4d","components/navigation/Breadcrumb.jsx":"89c6eb4329d6","components/navigation/Pagination.jsx":"d54a6a31e239","components/navigation/SiteFooter.jsx":"9e35dddba35b","components/navigation/SiteHeader.jsx":"36e5db65e327","ui_kits/website/AboutScreen.jsx":"82f3fd56343c","ui_kits/website/ArtistsScreen.jsx":"233ba00b2ae5","ui_kits/website/ArtworkScreen.jsx":"1c4ee152da11","ui_kits/website/CatalogScreen.jsx":"3f79580d55d7","ui_kits/website/HomeScreen.jsx":"5fcdb4d02dca","ui_kits/website/data.js":"32eaeae168eb"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ArtNiyyTliDesignSystem_1076d0 = window.ArtNiyyTliDesignSystem_1076d0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/catalog/ArtistCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ArtistCard({
  name,
  lifespan,
  discipline,
  city,
  worksCount,
  portrait,
  href,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: href || '#',
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      textDecoration: 'none',
      border: 0,
      color: 'var(--text-body)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '1 / 1',
      background: 'var(--surface-image)',
      border: '1px solid var(--line-hairline)',
      overflow: 'hidden',
      opacity: hover ? 0.88 : 1,
      transition: 'var(--transition-opacity)'
    }
  }, portrait ? /*#__PURE__*/React.createElement("img", {
    src: portrait,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 17,
      letterSpacing: 'var(--tracking-heading)',
      marginTop: 'var(--space-3)',
      color: hover ? 'var(--red-500)' : 'var(--text-body)',
      transition: 'var(--transition-color)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, [lifespan, discipline, city].filter(Boolean).join(' · ')), worksCount != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, worksCount, " \u0259s\u0259r") : null);
}
Object.assign(__ds_scope, { ArtistCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/catalog/ArtistCard.jsx", error: String((e && e.message) || e) }); }

// components/catalog/SpecTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SpecTable({
  rows = [],
  onDark = false,
  style,
  ...rest
}) {
  const line = onDark ? 'var(--line-on-dark)' : 'var(--line-hairline)';
  return /*#__PURE__*/React.createElement("dl", _extends({}, rest, {
    style: {
      margin: 0,
      ...style
    }
  }), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.label + i,
    style: {
      display: 'grid',
      gridTemplateColumns: '150px 1fr',
      gap: 'var(--space-4)',
      padding: '9px 0',
      borderTop: '1px solid ' + line
    }
  }, /*#__PURE__*/React.createElement("dt", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      letterSpacing: 'var(--tracking-label)',
      color: onDark ? 'var(--text-on-dark-muted)' : 'var(--text-muted)'
    }
  }, r.label), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0,
      fontSize: 15,
      color: onDark ? 'var(--text-on-dark)' : 'var(--text-body)'
    }
  }, r.value))));
}
Object.assign(__ds_scope, { SpecTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/catalog/SpecTable.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  sold: {
    color: 'var(--status-sold)',
    border: '1px solid var(--status-sold)'
  },
  reserved: {
    color: 'var(--status-reserved)',
    border: '1px solid var(--line-hairline)'
  },
  available: {
    color: 'var(--status-available)',
    border: '1px solid var(--line-strong)'
  },
  neutral: {
    color: 'var(--text-muted)',
    border: '1px solid var(--line-hairline)'
  }
};
function Badge({
  children,
  tone = 'neutral',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 12,
      letterSpacing: 'var(--tracking-label)',
      lineHeight: 1,
      padding: '3px 7px',
      borderRadius: 'var(--radius-0)',
      display: 'inline-block',
      whiteSpace: 'nowrap',
      ...tones[tone],
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/catalog/ArtworkMeta.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Əsər məlumatı hər yerdə eyni ardıcıllıqla: müəllif, ad və il, texnika və ölçü, qiymət. */
function ArtworkMeta({
  artist,
  title,
  year,
  medium,
  dimensions,
  price,
  status,
  size = 'md',
  style,
  ...rest
}) {
  const scale = size === 'lg' ? {
    artist: 17,
    title: 26,
    meta: 15,
    price: 16
  } : size === 'sm' ? {
    artist: 12,
    title: 14,
    meta: 12,
    price: 12
  } : {
    artist: 14,
    title: 19,
    meta: 14,
    price: 14
  };
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: scale.artist,
      letterSpacing: 'var(--tracking-heading)',
      color: 'var(--text-body)'
    }
  }, artist), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontStyle: 'italic',
      fontSize: scale.title,
      lineHeight: 1.25,
      marginTop: 2
    }
  }, title, year ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: 'normal'
    }
  }, ", ", year) : null), medium || dimensions ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: scale.meta,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, [medium, dimensions].filter(Boolean).join(' · ')) : null, price || status ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      marginTop: 6
    }
  }, price ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: scale.price
    }
  }, price) : null, status ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: status === 'Satılıb' ? 'sold' : 'reserved'
  }, status) : null) : null);
}
Object.assign(__ds_scope, { ArtworkMeta });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/catalog/ArtworkMeta.jsx", error: String((e && e.message) || e) }); }

// components/catalog/ArtworkCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ArtworkCard({
  artist,
  title,
  year,
  medium,
  dimensions,
  price,
  status,
  image,
  ratio = '4 / 5',
  href,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: href || '#',
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      textDecoration: 'none',
      border: 0,
      color: 'var(--text-body)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: ratio,
      background: 'var(--surface-image)',
      border: '1px solid var(--line-hairline)',
      overflow: 'hidden',
      opacity: hover ? 0.88 : 1,
      transition: 'var(--transition-opacity)'
    }
  }, image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : null), /*#__PURE__*/React.createElement(__ds_scope.ArtworkMeta, {
    style: {
      marginTop: 'var(--space-3)'
    },
    artist: artist,
    title: title,
    year: year,
    medium: medium,
    dimensions: dimensions,
    price: price,
    status: status
  }));
}
Object.assign(__ds_scope, { ArtworkCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/catalog/ArtworkCard.jsx", error: String((e && e.message) || e) }); }

// components/catalog/ExhibitionRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ExhibitionRow({
  dates,
  title,
  artists,
  status,
  href,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: href || '#',
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'grid',
      gridTemplateColumns: '190px 1fr auto',
      gap: 'var(--space-5)',
      alignItems: 'baseline',
      padding: 'var(--space-4) 0',
      borderTop: '1px solid var(--line-hairline)',
      textDecoration: 'none',
      border: 0,
      borderTop: '1px solid var(--line-hairline)',
      color: 'var(--text-body)',
      transition: 'var(--transition-color)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, dates), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 21,
      letterSpacing: 'var(--tracking-heading)',
      color: hover ? 'var(--red-500)' : 'var(--text-body)',
      transition: 'var(--transition-color)'
    }
  }, title), artists ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 14,
      color: 'var(--text-muted)',
      marginTop: 3
    }
  }, artists) : null), status ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "neutral"
  }, status) : null);
}
Object.assign(__ds_scope, { ExhibitionRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/catalog/ExhibitionRow.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const base = {
  fontFamily: 'var(--font-display)',
  fontWeight: 500,
  letterSpacing: 'var(--tracking-label)',
  borderRadius: 'var(--radius-0)',
  cursor: 'pointer',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 'var(--space-2)',
  textDecoration: 'none',
  boxShadow: 'none',
  transition: 'var(--transition-color)',
  lineHeight: 1
};
const sizes = {
  sm: {
    fontSize: 13,
    padding: '8px 14px'
  },
  md: {
    fontSize: 15,
    padding: '12px 20px'
  }
};
const variants = {
  solid: {
    background: 'var(--ink-900)',
    color: 'var(--ivory-200)',
    border: '1px solid var(--ink-900)'
  },
  outline: {
    background: 'transparent',
    color: 'var(--ink-900)',
    border: '1px solid var(--ink-900)'
  },
  quiet: {
    background: 'transparent',
    color: 'var(--ink-900)',
    border: '1px solid transparent',
    padding: 0
  },
  onDark: {
    background: 'transparent',
    color: 'var(--ivory-200)',
    border: '1px solid var(--ivory-200)'
  }
};
const hovers = {
  solid: {
    background: 'var(--bordo-800)',
    borderColor: 'var(--bordo-800)'
  },
  outline: {
    background: 'var(--ink-900)',
    color: 'var(--ivory-200)'
  },
  quiet: {
    color: 'var(--red-500)'
  },
  onDark: {
    background: 'var(--ivory-200)',
    color: 'var(--bordo-800)'
  }
};
function Button({
  children,
  variant = 'solid',
  size = 'md',
  disabled = false,
  href,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = {
    ...base,
    ...sizes[size],
    ...variants[variant],
    ...(hover && !disabled ? hovers[variant] : null),
    ...(variant === 'quiet' ? {
      borderBottom: '1px solid ' + (hover && !disabled ? 'var(--red-500)' : 'var(--ink-900)'),
      paddingBottom: 3
    } : null),
    ...(disabled ? {
      color: 'var(--ink-300)',
      borderColor: 'var(--line-hairline)',
      background: 'transparent',
      cursor: 'not-allowed'
    } : null),
    ...style
  };
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({}, rest, {
    href: href,
    type: href ? undefined : type,
    disabled: href ? undefined : disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: s
  }), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Divider({
  weight = 'hairline',
  onDark = false,
  style,
  ...rest
}) {
  const color = onDark ? 'var(--line-on-dark)' : weight === 'strong' ? 'var(--line-strong)' : 'var(--line-hairline)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    role: "separator",
    style: {
      borderTop: '1px solid ' + color,
      width: '100%',
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SectionHeader({
  title,
  note,
  action,
  onDark = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      borderTop: '1px solid ' + (onDark ? 'var(--line-on-dark)' : 'var(--line-strong)'),
      paddingTop: 'var(--space-3)',
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 'var(--space-5)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 'var(--size-display-3)',
      letterSpacing: 'var(--tracking-display)',
      lineHeight: 1.1,
      margin: 0,
      color: onDark ? 'var(--text-on-dark)' : 'var(--text-body)'
    }
  }, title), note ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 'var(--size-small)',
      marginTop: 6,
      maxWidth: 'var(--measure-narrow)',
      color: onDark ? 'var(--text-on-dark-muted)' : 'var(--text-muted)'
    }
  }, note) : null), action ? /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0
    }
  }, action) : null);
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/core/TextLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextLink({
  children,
  href = '#',
  onDark = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: href,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontFamily: 'inherit',
      color: onDark ? hover ? 'var(--ivory-200)' : 'var(--red-500)' : hover ? 'var(--bordo-800)' : 'var(--red-500)',
      borderBottom: '1px solid currentColor',
      textDecoration: 'none',
      transition: 'var(--transition-color)',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { TextLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/TextLink.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  checked = false,
  onChange,
  name,
  disabled = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-text)',
      fontSize: 'var(--size-small)',
      color: disabled ? 'var(--text-faint)' : 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({}, rest, {
    type: "checkbox",
    name: name,
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 14,
      height: 14,
      flexShrink: 0,
      borderRadius: 'var(--radius-0)',
      border: '1px solid ' + (disabled ? 'var(--line-hairline)' : 'var(--line-strong)'),
      background: checked ? 'var(--ink-900)' : 'transparent',
      boxShadow: checked ? 'inset 0 0 0 2px var(--surface-page)' : 'none',
      transition: 'var(--transition-color)'
    }
  }), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/FilterChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function FilterChip({
  children,
  active = false,
  count,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const color = active ? 'var(--filter-active-fg)' : hover ? 'var(--ink-900)' : 'var(--text-muted)';
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    "aria-pressed": active,
    style: {
      font: 'inherit',
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      letterSpacing: 'var(--tracking-label)',
      background: 'transparent',
      border: 0,
      borderBottom: '1px solid ' + (active ? 'var(--filter-active-line)' : 'transparent'),
      color,
      padding: '2px 0 4px',
      cursor: 'pointer',
      transition: 'var(--transition-color)',
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: 5,
      ...style
    }
  }), children, count != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: active ? 'var(--filter-active-fg)' : 'var(--text-faint)'
    }
  }, count) : null);
}
Object.assign(__ds_scope, { FilterChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FilterChip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  value,
  onChange,
  placeholder,
  type = 'text',
  name,
  id,
  disabled = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || name;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: 'block',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      letterSpacing: 'var(--tracking-label)',
      color: 'var(--text-muted)',
      display: 'block',
      marginBottom: 6
    }
  }, label) : null, /*#__PURE__*/React.createElement("input", _extends({}, rest, {
    id: inputId,
    name: name,
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      font: 'inherit',
      fontSize: 'var(--size-body)',
      color: 'var(--text-body)',
      background: 'var(--surface-raised)',
      padding: '10px 12px',
      borderRadius: 'var(--radius-2)',
      border: '1px solid ' + (error ? 'var(--red-500)' : focus ? 'var(--line-strong)' : 'var(--line-hairline)'),
      outline: 'none',
      transition: 'var(--transition-color)'
    }
  })), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-caption)',
      color: 'var(--red-500)',
      display: 'block',
      marginTop: 5
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-caption)',
      color: 'var(--text-muted)',
      display: 'block',
      marginTop: 5
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  value,
  onChange,
  options = [],
  name,
  id,
  disabled = false,
  style,
  ...rest
}) {
  const inputId = id || name;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: 'block',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      letterSpacing: 'var(--tracking-label)',
      color: 'var(--text-muted)',
      display: 'block',
      marginBottom: 6
    }
  }, label) : null, /*#__PURE__*/React.createElement("select", _extends({}, rest, {
    id: inputId,
    name: name,
    value: value,
    onChange: onChange,
    disabled: disabled,
    style: {
      width: '100%',
      font: 'inherit',
      fontFamily: 'var(--font-display)',
      fontSize: 15,
      color: 'var(--text-body)',
      background: 'var(--surface-raised)',
      padding: '9px 12px',
      borderRadius: 'var(--radius-2)',
      border: '1px solid var(--line-hairline)',
      appearance: 'none',
      outline: 'none',
      transition: 'var(--transition-color)'
    }
  }), options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  label,
  hint,
  value,
  onChange,
  placeholder,
  name,
  id,
  rows = 4,
  disabled = false,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || name;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: 'block',
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      letterSpacing: 'var(--tracking-label)',
      color: 'var(--text-muted)',
      display: 'block',
      marginBottom: 6
    }
  }, label) : null, /*#__PURE__*/React.createElement("textarea", _extends({}, rest, {
    id: inputId,
    name: name,
    rows: rows,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      font: 'inherit',
      fontSize: 'var(--size-body)',
      lineHeight: 'var(--leading-body)',
      color: 'var(--text-body)',
      background: 'var(--surface-raised)',
      padding: '10px 12px',
      borderRadius: 'var(--radius-2)',
      resize: 'vertical',
      border: '1px solid ' + (focus ? 'var(--line-strong)' : 'var(--line-hairline)'),
      outline: 'none',
      transition: 'var(--transition-color)'
    }
  })), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--size-caption)',
      color: 'var(--text-muted)',
      display: 'block',
      marginTop: 5
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumb.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Breadcrumb({
  items = [],
  onNavigate,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      alignItems: 'baseline',
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      letterSpacing: 'var(--tracking-label)',
      ...style
    }
  }), items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: it.label
    }, last ? /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-body)'
      }
    }, it.label) : /*#__PURE__*/React.createElement("a", {
      href: it.href || '#',
      onClick: e => {
        if (onNavigate) {
          e.preventDefault();
          onNavigate(it.id);
        }
      },
      style: {
        color: 'var(--text-muted)',
        textDecoration: 'none',
        border: 0,
        transition: 'var(--transition-color)'
      },
      onMouseEnter: e => {
        e.currentTarget.style.color = 'var(--red-500)';
      },
      onMouseLeave: e => {
        e.currentTarget.style.color = 'var(--text-muted)';
      }
    }, it.label), last ? null : /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-faint)'
      }
    }, "/"));
  }));
}
Object.assign(__ds_scope, { Breadcrumb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumb.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pagination.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Pagination({
  page = 1,
  pages = 1,
  onChange,
  style,
  ...rest
}) {
  const nums = Array.from({
    length: pages
  }, (_, i) => i + 1);
  const cell = on => ({
    fontFamily: 'var(--font-display)',
    fontSize: 14,
    background: 'transparent',
    border: 0,
    borderBottom: '1px solid ' + (on ? 'var(--line-strong)' : 'transparent'),
    color: on ? 'var(--text-body)' : 'var(--text-muted)',
    padding: '2px 4px 3px',
    cursor: 'pointer',
    transition: 'var(--transition-color)'
  });
  return /*#__PURE__*/React.createElement("nav", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'baseline',
      ...style
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      ...cell(false),
      opacity: page === 1 ? 0.4 : 1,
      cursor: page === 1 ? 'default' : 'pointer'
    },
    disabled: page === 1,
    onClick: () => onChange && onChange(page - 1)
  }, "\u0259vv\u0259lki"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, nums.map(n => /*#__PURE__*/React.createElement("button", {
    key: n,
    type: "button",
    style: cell(n === page),
    onClick: () => onChange && onChange(n)
  }, n))), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      ...cell(false),
      opacity: page === pages ? 0.4 : 1,
      cursor: page === pages ? 'default' : 'pointer'
    },
    disabled: page === pages,
    onClick: () => onChange && onChange(page + 1)
  }, "n\xF6vb\u0259ti"));
}
Object.assign(__ds_scope, { Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pagination.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteFooter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SiteFooter({
  logo,
  brand = 'Art Niyyətli',
  address,
  columns = [],
  note,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("footer", _extends({}, rest, {
    style: {
      background: 'var(--surface-dark)',
      color: 'var(--text-on-dark)',
      padding: 'var(--space-8) var(--page-pad) var(--space-6)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(' + Math.max(columns.length, 1) + ', 1fr)',
      gap: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("div", null, logo ? /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: brand,
    style: {
      height: 30,
      width: 'auto',
      marginBottom: 'var(--space-4)'
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 20,
      marginBottom: 'var(--space-4)'
    }
  }, brand), address ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-on-dark-muted)',
      maxWidth: '22em',
      lineHeight: 1.6
    }
  }, address) : null), columns.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.title
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 13,
      letterSpacing: 'var(--tracking-label)',
      color: 'var(--text-on-dark-muted)',
      marginBottom: 'var(--space-3)'
    }
  }, col.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, col.links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.label,
    href: l.href || '#',
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 15,
      color: 'var(--text-on-dark)',
      textDecoration: 'none',
      border: 0,
      transition: 'var(--transition-color)'
    },
    onMouseEnter: e => {
      e.currentTarget.style.color = 'var(--red-500)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.color = 'var(--text-on-dark)';
    }
  }, l.label)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--line-on-dark)',
      marginTop: 'var(--space-7)',
      paddingTop: 'var(--space-4)',
      fontSize: 13,
      color: 'var(--text-on-dark-muted)'
    }
  }, note));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SiteHeader({
  logo,
  brand = 'Art Niyyətli',
  items = [],
  active,
  onNavigate,
  onDark = false,
  style,
  ...rest
}) {
  const fg = onDark ? 'var(--text-on-dark)' : 'var(--text-body)';
  const muted = onDark ? 'var(--text-on-dark-muted)' : 'var(--text-muted)';
  return /*#__PURE__*/React.createElement("header", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-6)',
      padding: 'var(--space-5) var(--page-pad)',
      borderBottom: '1px solid ' + (onDark ? 'var(--line-on-dark)' : 'var(--line-hairline)'),
      background: onDark ? 'var(--surface-dark)' : 'var(--surface-page)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate(items[0] && items[0].id);
    },
    style: {
      border: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      textDecoration: 'none'
    }
  }, logo ? /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: brand,
    style: {
      height: 34,
      width: 'auto'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 20,
      letterSpacing: 'var(--tracking-display)',
      color: 'var(--red-500)'
    }
  }, brand)), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      alignItems: 'baseline'
    }
  }, items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("a", {
      key: it.id,
      href: it.href || '#',
      onClick: e => {
        if (onNavigate) {
          e.preventDefault();
          onNavigate(it.id);
        }
      },
      style: {
        fontFamily: 'var(--font-display)',
        fontSize: 15,
        letterSpacing: 'var(--tracking-label)',
        textDecoration: 'none',
        color: on ? 'var(--red-500)' : muted,
        borderBottom: '1px solid ' + (on ? 'var(--red-500)' : 'transparent'),
        paddingBottom: 3,
        transition: 'var(--transition-color)'
      },
      onMouseEnter: e => {
        if (!on) e.currentTarget.style.color = fg;
      },
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.color = muted;
      }
    }, it.label);
  })));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/AboutScreen.jsx
try { (() => {
const {
  SectionHeader,
  SpecTable,
  Input,
  Textarea,
  Button,
  TextLink,
  Divider
} = window.ArtNiyyTliDesignSystem_1076d0;
function AboutScreen() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("main", {
    style: {
      padding: 'var(--space-8) var(--page-pad) var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: "haqq\u0131nda"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.2fr) minmax(0,1fr)',
      gap: 'var(--space-8)',
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--size-body-lg)'
    }
  }, "Art Niyy\u0259tli Bak\u0131da f\u0259aliyy\u0259t g\xF6st\u0259r\u0259n m\xFCst\u0259qil kommersiya qalereyas\u0131d\u0131r. Se\xE7ilmi\u015F r\u0259ssamlar\u0131 t\u0259msil edir, \u0259s\u0259rl\u0259ri kolleksiya\xE7\u0131lara t\u0259qdim edir v\u0259 sat\u0131r."), /*#__PURE__*/React.createElement("p", null, "Qalereya 2016-c\u0131 ild\u0259 a\xE7\u0131lm\u0131\u015Fd\u0131r. \u0130ld\u0259 d\xF6rd s\u0259rgi ke\xE7irilir, kataloq iki h\u0259ft\u0259d\u0259 bir yenil\u0259nir. \u018Fs\u0259rl\u0259r birba\u015Fa r\u0259ssamdan al\u0131n\u0131r; h\u0259r sat\u0131\u015F m\u0259n\u015F\u0259 aray\u0131\u015F\u0131 il\u0259 s\u0259n\u0259dl\u0259\u015Fdirilir."), /*#__PURE__*/React.createElement("p", null, "Kolleksiya m\u0259sl\u0259h\u0259ti, \xE7\u0259r\xE7iv\u0259l\u0259m\u0259 v\u0259 da\u015F\u0131nma xidm\u0259tl\u0259ri ayr\u0131ca raz\u0131la\u015Fd\u0131r\u0131l\u0131r. Sor\u011Fular \xFC\xE7\xFCn ", /*#__PURE__*/React.createElement(TextLink, {
    href: "mailto:info@artniyyetli.az"
  }, "info@artniyyetli.az"), "."), /*#__PURE__*/React.createElement(SpecTable, {
    style: {
      marginTop: 'var(--space-6)'
    },
    rows: [{
      label: 'ünvan',
      value: 'Bakı, Nizami küçəsi 00'
    }, {
      label: 'iş saatları',
      value: 'çərşənbə — şənbə, 12:00—19:00'
    }, {
      label: 'telefon',
      value: '+994 12 000 00 00'
    }, {
      label: 'e-poçt',
      value: 'info@artniyyetli.az'
    }]
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4 / 3',
      background: 'var(--surface-image)',
      border: '1px solid var(--line-hairline)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-7)',
      borderTop: '1px solid var(--line-strong)',
      paddingTop: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "kataloq bildiri\u015Fl\u0259ri"), sent ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15
    }
  }, "Abun\u0259liyiniz qeyd\u0259 al\u0131nd\u0131.") : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    name: "epost",
    label: "e-po\xE7t",
    type: "email",
    placeholder: "ad@n\xFCmun\u0259.az",
    hint: "Ayda bir m\u0259ktub: yeni \u0259s\u0259rl\u0259r v\u0259 s\u0259rgi tarixl\u0259ri."
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "outline"
  }, "abun\u0259 ol")))), /*#__PURE__*/React.createElement(Divider, {
    style: {
      marginTop: 'var(--space-7)'
    }
  }))));
}
Object.assign(window, {
  AboutScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/AboutScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ArtistsScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  SectionHeader,
  ArtistCard,
  ArtworkMeta,
  Divider,
  TextLink
} = window.ArtNiyyTliDesignSystem_1076d0;
function ArtistsScreen({
  openWork
}) {
  const d = window.ANI;
  const [selected, setSelected] = React.useState(d.artists[0].id);
  const a = d.artists.find(x => x.id === selected);
  const works = d.works.filter(w => w.artist === a.name);
  return /*#__PURE__*/React.createElement("main", {
    style: {
      padding: 'var(--space-8) var(--page-pad) var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: "r\u0259ssamlar",
    note: "Qalereya on iki r\u0259ssam\u0131 t\u0259msil edir. D\xF6rd\xFC a\u015Fa\u011F\u0131da g\xF6st\u0259rilir."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0,1fr))',
      gap: 'var(--column-gap)',
      marginTop: 'var(--space-6)'
    }
  }, d.artists.map(x => /*#__PURE__*/React.createElement(ArtistCard, _extends({
    key: x.id
  }, window.artistProps(x), {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setSelected(x.id);
    },
    style: x.id === selected ? {
      borderBottom: '1px solid var(--red-500)',
      paddingBottom: 'var(--space-3)'
    } : null
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-9)',
      borderTop: '1px solid var(--line-strong)',
      paddingTop: 'var(--space-5)',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.6fr)',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0
    }
  }, a.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, [a.lifespan, a.discipline, a.city].join(' · ')), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-4)'
    }
  }, a.bio), /*#__PURE__*/React.createElement(TextLink, {
    href: "#"
  }, "cv s\u0259n\u0259di")), /*#__PURE__*/React.createElement("div", null, works.map(w => /*#__PURE__*/React.createElement("a", {
    key: w.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      openWork(w.id);
    },
    style: {
      display: 'grid',
      gridTemplateColumns: '84px 1fr',
      gap: 'var(--space-4)',
      alignItems: 'start',
      borderTop: '1px solid var(--line-hairline)',
      padding: 'var(--space-4) 0',
      textDecoration: 'none',
      border: 0,
      borderTop: '1px solid var(--line-hairline)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4 / 5',
      background: 'var(--surface-image)',
      border: '1px solid var(--line-hairline)'
    }
  }), /*#__PURE__*/React.createElement(ArtworkMeta, window.cardProps(w)))), works.length ? /*#__PURE__*/React.createElement(Divider, null) : /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Kataloqda \u0259s\u0259r yoxdur."))));
}
Object.assign(window, {
  ArtistsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ArtistsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ArtworkScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Breadcrumb,
  ArtworkMeta,
  SpecTable,
  Button,
  Input,
  Textarea,
  TextLink,
  SectionHeader,
  ArtworkCard,
  Divider
} = window.ArtNiyyTliDesignSystem_1076d0;
function ArtworkScreen({
  workId,
  go,
  openWork
}) {
  const d = window.ANI;
  const w = d.works.find(x => x.id === workId) || d.works[0];
  const artist = d.artists.find(a => a.name === w.artist);
  const others = d.works.filter(x => x.artist === w.artist && x.id !== w.id).slice(0, 3);
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("main", {
    style: {
      padding: 'var(--space-6) var(--page-pad) var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(Breadcrumb, {
    items: [{
      id: 'catalog',
      label: 'kataloq'
    }, {
      label: w.category
    }, {
      label: w.title
    }],
    onNavigate: go
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.35fr) minmax(0,1fr)',
      gap: 'var(--space-8)',
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: w.ratio,
      background: 'var(--surface-image)',
      border: '1px solid var(--line-hairline)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ArtworkMeta, _extends({
    size: "lg"
  }, window.cardProps(w))), /*#__PURE__*/React.createElement(SpecTable, {
    style: {
      marginTop: 'var(--space-6)'
    },
    rows: [{
      label: 'kateqoriya',
      value: w.category
    }, {
      label: 'kataloq nömrəsi',
      value: 'AN-' + w.year + '-0' + w.id
    }, {
      label: 'çərçivə',
      value: 'çərçivəsiz'
    }, {
      label: 'mənşə',
      value: 'rəssamdan birbaşa'
    }, {
      label: 'sertifikat',
      value: 'var'
    }]
  }), artist ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-6)',
      fontSize: 15
    }
  }, artist.bio, " ", /*#__PURE__*/React.createElement(TextLink, {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go('artists');
    }
  }, "r\u0259ssam haqq\u0131nda")) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-7)',
      borderTop: '1px solid var(--line-strong)',
      paddingTop: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "\u0259s\u0259r bar\u0259d\u0259 sor\u011Fu"), sent ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      margin: 0
    }
  }, "Sor\u011Funuz qeyd\u0259 al\u0131nd\u0131. Qalereya iki i\u015F g\xFCn\xFC \u0259rzind\u0259 cavab verir.") : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      maxWidth: 440
    }
  }, /*#__PURE__*/React.createElement(Input, {
    name: "ad",
    label: "ad v\u0259 soyad",
    placeholder: "Ad\u0131n\u0131z"
  }), /*#__PURE__*/React.createElement(Input, {
    name: "epost",
    label: "e-po\xE7t",
    type: "email",
    placeholder: "ad@n\xFCmun\u0259.az"
  }), /*#__PURE__*/React.createElement(Textarea, {
    name: "mesaj",
    label: "mesaj",
    rows: 3,
    placeholder: '«' + w.title + '» haqqında sualınız'
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "solid"
  }, "sor\u011Fu g\xF6nd\u0259r")))))), others.length ? /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: 'həmin rəssamın digər əsərləri'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0,1fr))',
      gap: 'var(--column-gap)',
      marginTop: 'var(--space-6)'
    }
  }, others.map(o => /*#__PURE__*/React.createElement(ArtworkCard, _extends({
    key: o.id
  }, window.cardProps(o), {
    onClick: e => {
      e.preventDefault();
      openWork(o.id);
    }
  }))))) : /*#__PURE__*/React.createElement(Divider, {
    style: {
      marginTop: 'var(--space-9)'
    }
  }));
}
Object.assign(window, {
  ArtworkScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ArtworkScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CatalogScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  SectionHeader,
  FilterChip,
  Select,
  Checkbox,
  ArtworkCard,
  Pagination,
  Divider
} = window.ArtNiyyTliDesignSystem_1076d0;
function CatalogScreen({
  openWork
}) {
  const d = window.ANI;
  const [cat, setCat] = React.useState('hamısı');
  const [sort, setSort] = React.useState('yeni əsərlər');
  const [available, setAvailable] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const cats = ['hamısı', 'rəsm', 'qrafika', 'heykəl'];
  const count = c => c === 'hamısı' ? d.works.length : d.works.filter(w => w.category === c).length;
  let works = cat === 'hamısı' ? d.works : d.works.filter(w => w.category === cat);
  if (available) works = works.filter(w => !w.status);
  if (sort === 'qiymət artan') works = [...works].sort((a, b) => num(a.price) - num(b.price));
  if (sort === 'qiymət azalan') works = [...works].sort((a, b) => num(b.price) - num(a.price));
  return /*#__PURE__*/React.createElement("main", {
    style: {
      padding: 'var(--space-8) var(--page-pad) var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: "kataloq",
    note: "Qalereyada m\xF6vcud olan \u0259s\u0259rl\u0259r. Qiym\u0259tl\u0259r manatla g\xF6st\u0259rilir."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 'var(--space-6)',
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      alignItems: 'baseline',
      flexWrap: 'wrap'
    }
  }, cats.map(c => /*#__PURE__*/React.createElement(FilterChip, {
    key: c,
    active: cat === c,
    count: count(c),
    onClick: () => {
      setCat(c);
      setPage(1);
    }
  }, c)), /*#__PURE__*/React.createElement(Checkbox, {
    label: "yaln\u0131z m\xF6vcud \u0259s\u0259rl\u0259r",
    checked: available,
    onChange: () => setAvailable(!available)
  })), /*#__PURE__*/React.createElement(Select, {
    value: sort,
    onChange: e => setSort(e.target.value),
    style: {
      width: 200
    },
    options: ['yeni əsərlər', 'qiymət artan', 'qiymət azalan']
  })), /*#__PURE__*/React.createElement(Divider, {
    style: {
      marginTop: 'var(--space-5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0,1fr))',
      gap: 'var(--column-gap) var(--column-gap)',
      rowGap: 'var(--row-gap)',
      marginTop: 'var(--space-7)'
    }
  }, works.map(w => /*#__PURE__*/React.createElement(ArtworkCard, _extends({
    key: w.id
  }, window.cardProps(w), {
    onClick: e => {
      e.preventDefault();
      openWork(w.id);
    }
  })))), works.length === 0 ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-6)',
      color: 'var(--text-muted)'
    }
  }, "Bu filtrl\u0259 uy\u011Fun \u0259s\u0259r yoxdur.") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-9)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, works.length, " \u0259s\u0259r g\xF6st\u0259rilir"), /*#__PURE__*/React.createElement(Pagination, {
    page: page,
    pages: 3,
    onChange: setPage
  })));
}
function num(p) {
  return p ? parseInt(String(p).replace(/[^0-9]/g, ''), 10) : 0;
}
Object.assign(window, {
  CatalogScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CatalogScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  SectionHeader,
  TextLink,
  Button,
  ArtworkCard,
  ExhibitionRow,
  Divider
} = window.ArtNiyyTliDesignSystem_1076d0;
function HomeScreen({
  go,
  openWork
}) {
  const d = window.ANI;
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: 'var(--space-9) var(--page-pad) var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-8)',
      alignItems: 'end'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 14,
      color: 'var(--text-muted)',
      marginBottom: 'var(--space-4)'
    }
  }, "haz\u0131rk\u0131 s\u0259rgi \xB7 ", d.exhibition.dates), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0
    }
  }, d.exhibition.title), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-5)',
      fontSize: 'var(--size-body-lg)'
    }
  }, d.exhibition.note), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      color: 'var(--text-muted)'
    }
  }, d.exhibition.artists), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-6)',
      display: 'flex',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "solid",
    onClick: () => go('catalog')
  }, "kataloqa ke\xE7"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => go('about')
  }, "qalereya haqq\u0131nda"))), /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4 / 3',
      background: 'var(--surface-image)',
      border: '1px solid var(--line-hairline)'
    }
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 var(--page-pad) var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: "se\xE7ilmi\u015F \u0259s\u0259rl\u0259r",
    note: "Kataloq iki h\u0259ft\u0259d\u0259 bir yenil\u0259nir.",
    action: /*#__PURE__*/React.createElement(TextLink, {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go('catalog');
      }
    }, "b\xFCt\xFCn kataloq")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, minmax(0,1fr))',
      gap: 'var(--column-gap)',
      marginTop: 'var(--space-6)'
    }
  }, d.works.slice(0, 4).map(w => /*#__PURE__*/React.createElement(ArtworkCard, _extends({
    key: w.id
  }, window.cardProps(w), {
    onClick: e => {
      e.preventDefault();
      openWork(w.id);
    }
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-dark)',
      color: 'var(--text-on-dark)',
      padding: 'var(--space-9) var(--page-pad)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      color: 'var(--text-on-dark)',
      margin: 0
    }
  }, "qalereya on iki r\u0259ssam\u0131 t\u0259msil edir"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-on-dark)',
      fontSize: 'var(--size-body-lg)',
      margin: 0
    }
  }, "\u018Fs\u0259rl\u0259r birba\u015Fa r\u0259ssamdan al\u0131n\u0131r v\u0259 kolleksiya\xE7\u0131lara s\u0259n\u0259dl\u0259\u015Fdirilmi\u015F \u015F\u0259kild\u0259 t\u0259qdim edilir. H\u0259r sat\u0131\u015F \xFC\xE7\xFCn m\u0259n\u015F\u0259 aray\u0131\u015F\u0131 verilir."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "onDark",
    onClick: () => go('artists')
  }, "r\u0259ssamlar"))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: 'var(--space-9) var(--page-pad)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: "s\u0259rgil\u0259r"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-5)'
    }
  }, d.exhibitions.map(e => /*#__PURE__*/React.createElement(ExhibitionRow, _extends({
    key: e.title
  }, e))), /*#__PURE__*/React.createElement(Divider, null))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
window.ANI = {
  nav: [{
    id: 'home',
    label: 'ana səhifə'
  }, {
    id: 'catalog',
    label: 'kataloq'
  }, {
    id: 'artists',
    label: 'rəssamlar'
  }, {
    id: 'about',
    label: 'haqqında'
  }],
  exhibition: {
    dates: '12.10 — 30.11.2024',
    title: 'dörd otaq',
    artists: 'Nərmin Əliyeva, Rəşad Hüseynov, Leyla Qasımova',
    note: 'Üç rəssamın 2023—2024 illərində tamamladığı on doqquz əsər. Giriş sərbəstdir.'
  },
  works: [{
    id: 1,
    artist: 'Nərmin Əliyeva',
    title: 'Kölgəli həyət',
    year: '2024',
    medium: 'kətan üzərində yağlı boya',
    dimensions: '90 × 70 sm',
    price: '4 800 ₼',
    category: 'rəsm',
    ratio: '4 / 5'
  }, {
    id: 2,
    artist: 'Rəşad Hüseynov',
    title: 'İkinci sahil',
    year: '2023',
    medium: 'kətan üzərində akril',
    dimensions: '120 × 90 sm',
    price: '6 200 ₼',
    status: 'Satılıb',
    category: 'rəsm',
    ratio: '4 / 3'
  }, {
    id: 3,
    artist: 'Leyla Qasımova',
    title: 'Kağız üzərində qeyd',
    year: '2024',
    medium: 'kağız üzərində tuş',
    dimensions: '42 × 30 sm',
    price: '1 200 ₼',
    category: 'qrafika',
    ratio: '3 / 4'
  }, {
    id: 4,
    artist: 'Tural Məmmədov',
    title: 'Duman',
    year: '2022',
    medium: 'kətan üzərində yağlı boya',
    dimensions: '70 × 70 sm',
    price: '3 400 ₼',
    category: 'rəsm',
    ratio: '1 / 1'
  }, {
    id: 5,
    artist: 'Nərmin Əliyeva',
    title: 'Səhər otağı',
    year: '2023',
    medium: 'kətan üzərində yağlı boya',
    dimensions: '110 × 80 sm',
    price: '5 600 ₼',
    category: 'rəsm',
    ratio: '4 / 5'
  }, {
    id: 6,
    artist: 'Leyla Qasımova',
    title: 'On yeddi xətt',
    year: '2024',
    medium: 'kağız üzərində quru iynə',
    dimensions: '38 × 28 sm',
    price: '900 ₼',
    status: 'Saxlanılıb',
    category: 'qrafika',
    ratio: '3 / 4'
  }, {
    id: 7,
    artist: 'Rəşad Hüseynov',
    title: 'Qapalı forma',
    year: '2024',
    medium: 'bürünc',
    dimensions: '44 × 20 × 20 sm',
    price: '7 500 ₼',
    category: 'heykəl',
    ratio: '3 / 4'
  }, {
    id: 8,
    artist: 'Tural Məmmədov',
    title: 'Boş sahil',
    year: '2021',
    medium: 'kətan üzərində akril',
    dimensions: '150 × 100 sm',
    price: '8 900 ₼',
    category: 'rəsm',
    ratio: '3 / 2'
  }],
  artists: [{
    id: 'nermin',
    name: 'Nərmin Əliyeva',
    lifespan: 'b. 1984',
    discipline: 'rəsm',
    city: 'Bakı',
    worksCount: 14,
    bio: 'Bakıda yaşayır və işləyir. Əsərləri şəhər interyerlərinin işığı üzərində qurulur. 2019-cu ildən qalereya tərəfindən təmsil olunur.'
  }, {
    id: 'reshad',
    name: 'Rəşad Hüseynov',
    lifespan: 'b. 1979',
    discipline: 'rəsm, heykəl',
    city: 'Bakı',
    worksCount: 11,
    bio: 'Kətan və bürünc üzərində paralel işləyir. Son sərgisi 2023-cü ildə Tbilisidə keçirilib.'
  }, {
    id: 'leyla',
    name: 'Leyla Qasımova',
    lifespan: 'b. 1991',
    discipline: 'qrafika',
    city: 'Gəncə',
    worksCount: 9,
    bio: 'Quru iynə və tuş texnikasında kiçik formatlı əsərlər yaradır. Kağız üzərində işlərin arxivi qalereyada saxlanılır.'
  }, {
    id: 'tural',
    name: 'Tural Məmmədov',
    lifespan: 'b. 1972',
    discipline: 'rəsm',
    city: 'Bakı',
    worksCount: 8,
    bio: 'Xəzərin sahil xəttini otuz ildir çəkir. Əsərləri özəl kolleksiyalardadır.'
  }],
  exhibitions: [{
    dates: '12.10 — 30.11.2024',
    title: 'dörd otaq',
    artists: 'N. Əliyeva, R. Hüseynov, L. Qasımova',
    status: 'davam edir'
  }, {
    dates: '04.05 — 20.06.2024',
    title: 'kağız üzərində',
    artists: 'L. Qasımova',
    status: 'arxiv'
  }, {
    dates: '18.01 — 02.03.2024',
    title: 'sahil xətti',
    artists: 'T. Məmmədov',
    status: 'arxiv'
  }]
};
window.cardProps = w => ({
  artist: w.artist,
  title: w.title,
  year: w.year,
  medium: w.medium,
  dimensions: w.dimensions,
  price: w.price,
  status: w.status,
  image: w.image,
  ratio: w.ratio
});
window.artistProps = a => ({
  name: a.name,
  lifespan: a.lifespan,
  discipline: a.discipline,
  city: a.city,
  worksCount: a.worksCount,
  portrait: a.portrait
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

__ds_ns.ArtistCard = __ds_scope.ArtistCard;

__ds_ns.ArtworkCard = __ds_scope.ArtworkCard;

__ds_ns.ArtworkMeta = __ds_scope.ArtworkMeta;

__ds_ns.ExhibitionRow = __ds_scope.ExhibitionRow;

__ds_ns.SpecTable = __ds_scope.SpecTable;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.TextLink = __ds_scope.TextLink;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.FilterChip = __ds_scope.FilterChip;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Breadcrumb = __ds_scope.Breadcrumb;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

})();
