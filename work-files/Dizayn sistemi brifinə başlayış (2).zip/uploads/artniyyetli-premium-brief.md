# ArtNiyyətli / Dizayn brifi

Sən beynəlxalq səviyyəli qalereya saytları hazırlayan dizayn studiyasının art direktorusan. Bu müştəri şablon həlləri artıq rədd edib. Ondan gözlənilən açıq bir baxış bucağıdır.

Nəticə: interaktiv, tam responsiv, yüksək keyfiyyətli HTML prototip.

---

## 1. Kim üçün

**ArtNiyyətli**, Bakıda fəaliyyət göstərən müstəqil kommersiya incəsənət qalereyası. Seçilmiş rəssamları təmsil edir, əsərləri kolleksiyaçılara təqdim edir və satır. İlk rəsmi satış sərgisi aprel 2027.

Sayta girən adam kolleksiyaçıdır. O, əsəri ekranda görür, amma divarında təsəvvür etməlidir. Onun beynindəki suallar sırayla belədir: bu nədir, kim çəkib, nə boydadır, mövcuddurmu, neçəyədir, kimlə danışım.

Bu sayt həmin sıranı pozmadan cavablandırır.

**Bu sayt nə deyil:** bloq deyil, jurnal deyil, influenser səhifəsi deyil, portfolio deyil. Kommersiya qalereyasıdır və bunu ilk ekranda hiss etdirir.

## 2. Əsas ideya

Ekranda əsərin ölçüsü itir. Kolleksiyaçının ən böyük sualı budur: bu əsər mənim divarımda necə görünəcək.

Bütün sayt bu problemin həlli üzərində qurulur. Konsepsiyanın adı: **Divar**.

Bu, dekorativ fikir deyil, funksional üstünlükdür. Rəqib qalereya saytlarının heç birində yoxdur və müştəri onu ilk saniyədə görəcək.

Konsepsiya üç yerdə özünü göstərir:

**a) Ana səhifənin açılışı.** Ekran bir divardır. Əsərlər həmin divarda öz real nisbi ölçüləri ilə asılıb. Böyük əsər böyük, kiçik əsər kiçik görünür. Sürüşdürəndə divar boyunca üfüqi hərəkət edirsən, sanki qalereyada gəzirsən. Divarın sol kənarında nazik bir insan boyu göstəricisi var: 170 sm. Miqyas dərhal anlaşılır.

**b) Əsərin detal səhifəsi.** "Divarda gör" keçidi. Basanda əsər 2.7 metrlik divar fonunda, insan siluetinin yanında öz həqiqi ölçüsündə görünür. Bu, saytın yadda qalan anıdır.

**c) Kataloq.** Grid-də əsərlər eyni ölçüdə kəsilmir. Hər biri öz en-boy nisbətini saxlayır və nisbi ölçüsünü qoruyur. Sətir hündürlüyü ən böyük əsərə görə təyin olunur. Bu, kataloqa canlı, əl ilə düzülmüş divar ritmi verir.

**Cəsarəti bir yerə xərclə: bu konsepsiya.** Qalan hər şey sakit, nizamlı və ciddi qalsın.

## 3. Vizual dil

### Rəng

Sayt iki iqlimdə yaşayır. Gündüz kataloq, gecə sərgi.

| Ad | Hex | Rol |
|---|---|---|
| Bone | `#F4F0E8` | Əsas fon. İsti fil sümüyü, sarıya qaçmayan |
| Ink | `#1A1614` | Mətn və başlıqlar |
| Ash | `#6E665F` | Meta məlumat, ikinci dərəcəli mətn |
| Bordo | `#3E0B0A` | Sərgi bölməsi, footer, "gecə" ekranları |
| Signal | `#F51000` | Loqo qırmızısı |
| Line | `#DDD6CA` | Nazik ayırıcılar, çərçivə xətləri |

**Signal qaydası:** bu rəng heç vaxt fon və ya böyük sahə deyil. Yalnız aktiv filtr, link hover, "Satılıb" nişanı və inventar kodunun altındakı nazik xətt. Bir ekranda üç yerdən çox görünməsin. Az işlədildikcə güclü qalır.

**Bordo bölmə** saytın nəfəs aldığı yerdir. Sərgi elanı və footer bordo fonda, mətnlər Bone rəngində. Keçid kəskin olsun, gradient olmasın.

### Tipoqrafiya

İki ailə, aydın fərqlə.

**Başlıqlar:** dar, kontrastlı qrotesk. Neue Haas Grotesk Display, Söhne Breit və ya Archivo Condensed səviyyəsində. Loqo tipoqrafiyası ilə eyni ailədən hiss olunsun. Böyük ölçü, sıx letter-spacing (-0.02em), kiçik hərflər üstünlük təşkil edir.

**Mətn və kataloq məlumatı:** oxunaqlı serif. Lyon Text, Freight Text və ya Source Serif səviyyəsində. Sətir uzunluğu 68 simvoldan az, sətir hündürlüyü 1.6.

**Əsər adları serif və italik.** Bu, qalereya kataloqu ənənəsidir və saytı jurnal görüntüsündən ayırır. Heç bir başqa yerdə italik işlətmə.

Tipoqrafik şkala: 13 / 15 / 17 / 22 / 32 / 54 / 96px. Aralıq ölçü yaratma.

Azərbaycan hərfləri mütləq düzgün göstərilsin: ə, ö, ü, ğ, ı, ş, ç, Ə.

### Kataloq sətri

Bütün saytda, istisnasız, eyni struktur və eyni ardıcıllıq:

```
Nərmin Qasımova
Səssiz otaq, 2025
Kətan üzərində yağlı boya, 120 × 90 sm
6 400 AZN
AN-2025-014
```

Beş sətir. Ad qrotesk, əsərin adı serif italik, texnika və ölçü Ash rəngində, qiymət Ink, inventar kodu ən kiçik ölçüdə və Ash rəngində.

**İnventar kodu** dekorasiya deyil, real qalereya praktikasıdır. Kolleksiyaçı onunla müraciət edir. Buna görə hər əsərdə görünür və detal səhifəsində kopyalana bilir. 01 / 02 / 03 tipli süni nömrələmə işlətmə.

### Qadağalar

- Rəsm palitrası, fırça, molbert ikonoqrafiyası
- Gradient, yumşaq kölgə, eyni radiuslu kart yığını
- Başlıqların üstündə boşluqlu BÖYÜK HƏRFLİ etiket
- Hər bölmədə təkrarlanan yuxarı sürüşmə animasiyası
- Bir sözü fərqli rəngdə vurğulanmış başlıq
- Düymə mətninin sonunda ox işarəsi
- Nöqtələrlə birləşdirilmiş meta sətirlər
- Stok "art" fotoları. Əsər yerinə tutqun düz rəng sahələri işlət, üzərində əsərin adı və ölçüsü yazılsın.

## 4. Ekranlar

### Ana səhifə

**Açılış: Divar.** Ekranın tam eni. Bone fonda beş əsər öz nisbi ölçüləri ilə asılıb, aralarında qeyri-bərabər, əl ilə düzülmüş kimi boşluqlar var. Sol kənarda incə 170 sm göstəricisi. Sürüşdürmə üfüqidir. Səhifə yüklənəndə divar bir dəfə, yavaş şəkildə sağa doğru bir neçə piksel sürüşür ki, adam üfüqi hərəkəti anlasın. Bu, saytdakı yeganə avtomatik hərəkətdir.

Divarın üstündə, sol yuxarıda, kiçik ölçüdə bir cümlə:

> Müasir Azərbaycan rəssamlığını təmsil edirik və əsərləri birbaşa kolleksiyalara çatdırırıq.

Slayder qoyma. Böyük düymə qoyma. Divarın özü çağırışdır.

**Sonrakı bölmələr:**

1. **Qalereya haqqında.** Üç cümlə, iri serif, sol tərəfə düzlənmiş, çoxlu boşluq içində.
2. **Yeni əlavələr.** Altı əsər, nisbi ölçülərini qoruyan grid.
3. **Təmsil olunan rəssamlar.** Dörd ad, portretlər kiçik və tutqun, adlar iri qrotesk. Ada yaxınlaşanda portret aydınlaşır.
4. **Sərgi.** Bordo fonda, tam eni. "İlk satış sərgisi, aprel 2027" və qısa mətn.
5. **Footer.** Bordo. Əlaqə, ünvan, iş saatları, sosial şəbəkə, dil seçimi AZ / EN.

### Kataloq (Əsərlər)

Filtrlər yuxarıda, bir sətirdə, açılan siyahılar şəklində: rəssam, janr, texnika, qiymət aralığı, mövcudluq.

Seçilmiş filtrlər altda kiçik nişanlar kimi görünür, hər birinin yanında silmə işarəsi, sağda "Hamısını sil". Aktiv filtr Signal rəngində nazik altxətt alır.

Grid əsərlərin nisbi ölçüsünü qoruyur. Satılmış əsərlərdə küncdə kiçik, Signal rəngli "Satılıb" yazısı. Şəkil solğunlaşmır, əsər hörmətlə göstərilir.

Sağ yuxarıda nəticə sayı: "24 əsər".

### Əsərin detal səhifəsi

Bu, saytın ən vacib ekranıdır. Satış burada bağlanır.

**Sol tərəf (60%):** böyük əsas foto. Altında üç kiçik foto: detal, çərçivə, divarda görünüş. Əsas fotonun üstündə iki keçid:

- **Divarda gör.** Basanda əsər 2.7 m hündürlüyündə divar fonunda, 170 sm insan siluetinin yanında həqiqi nisbətdə görünür. Altda yazı: "Əsərin ölçüsü 120 × 90 sm".
- **Yaxınlaşdır.** Fırça izini görmək üçün.

**Sağ tərəf (40%, sabit):** kataloq sətri tam formada, altında mövcudluq vəziyyəti, qiymət, sonra iki hərəkət:

- "Bu əsər haqqında soruş" (form açır)
- "WhatsApp ilə yaz"

Altında nazik xətlə ayrılmış texniki blok: mənşə, sertifikat, çərçivə vəziyyəti, çatdırılma qeydi.

Səhifənin altında həmin rəssamın digər əsərləri.

### Rəssam profili

Yuxarıda rəssamın adı çox iri qrotesk hərflərlə, altında doğum ili və yeri. Portret sağda, kiçik və sakit.

İki mətn bloku: bioqrafiya və yaradıcılıq yanaşması. Serif, dar sütun.

Sonra sərgi və mükafat siyahısı, il və ad şəklində, nazik xətlərlə ayrılmış.

Ən altda rəssamın bütün əsərləri, kataloq gridi ilə eyni məntiqdə.

## 5. Demo məzmunu

Uydurma, amma inandırıcı. Azərbaycan konteksti.

**Rəssamlar:**
- Nərmin Qasımova, 1988, Bakı. Məkan və yaddaş üzərində işləyir.
- Rəşad Ələkbərov olmayan bir ad seçilsin, məsələn Kamran Səfərli, 1979, Gəncə. Kətan üzərində iri miqyaslı abstraksiya.
- Aysel Mehdiyeva, 1994, Şəki. Kağız və ipək üzərində qarışıq texnika.
- Elçin Babayev, 1971, Bakı. Fiqurativ rəssamlıq, portret.

**Əsərlər (səkkiz ədəd):** adları azərbaycanca, illər 2019 ilə 2026 arası, texnikalar: kətan üzərində yağlı boya, kağız üzərində qarışıq texnika, kətan üzərində akril, ipək üzərində çap. Ölçülər 40 × 30 sm ilə 180 × 140 sm arasında dəyişsin, çünki nisbi ölçü konsepsiyası bundan asılıdır. Qiymətlər 900 AZN ilə 14 000 AZN arasında. Bir əsər satılmış, bir əsər "Qiymət üçün müraciət" olsun.

**Mətn tonu:** quru, dəqiq, təmkinli. Sifət azlığı. "Möhtəşəm", "unikal", "əfsanəvi" kimi sözlər yoxdur. Qalereya kataloqu yazır, reklam agentliyi yox.

## 6. Keyfiyyət həddi

- Mobil əvvəlcə. 375px-də Divar üfüqidən şaquliyə çevrilir, amma nisbi ölçü qorunur və miqyas göstəricisi qalır.
- Klaviatura ilə tam naviqasiya, görünən focus vəziyyəti
- `prefers-reduced-motion` nəzərə alınır, divarın açılış hərəkəti söndürülür
- Şəkillərin en-boy nisbəti öncədən müəyyəndir, layout sıçramır
- Kontrast nisbətləri AA səviyyəsində
- Bütün komponentlər təkrar istifadə üçün qurulur, çünki məzmun sonradan idarəetmə panelindən gələcək

---

## İşin ardıcıllığı

1. **Kod yazma.** Əvvəlcə dizayn planını təqdim et: rəng tokenləri, şrift rolları və şkala, Divar konsepsiyasının texniki həlli, ASCII eskizlə layout, üç əsas prinsip.
2. Planı bu brifə qarşı yoxla. Hər hansı hissə istənilən qalereya saytına yaraşan ümumi həll kimi görünürsə, dəyiş və nəyi niyə dəyişdiyini bir cümlə ilə izah et.
3. Təsdiqdən sonra əvvəlcə **yalnız əsərin detal səhifəsini** qur. Ən çətin ekran odur, qalanları ondan törəyir.
4. Sonra kataloq, ana səhifə, rəssam profili. Eyni tokenlər, eyni komponentlər.
5. Sonda özünü tənqid et və bir artıq elementi çıxar.
